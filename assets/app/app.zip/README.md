# A site Flet app

An example of a minimal Flet app.

To run the app:

```
flet run [app_directory]
```